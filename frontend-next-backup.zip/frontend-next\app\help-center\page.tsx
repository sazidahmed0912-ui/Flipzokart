import Component from '@/app/_pages/HelpCenterPage';

export default function Page() {
  return <Component />;
}
