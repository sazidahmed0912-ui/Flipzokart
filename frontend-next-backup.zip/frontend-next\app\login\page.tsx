import { LoginPage as Component } from '@/app/_pages/LoginPage';

export default function Page() {
  return <Component />;
}
