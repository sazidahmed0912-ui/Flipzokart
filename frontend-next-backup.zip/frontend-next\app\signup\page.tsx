import { SignupPage as Component } from '@/app/_pages/SignupPage';

export default function Page() {
  return <Component />;
}
