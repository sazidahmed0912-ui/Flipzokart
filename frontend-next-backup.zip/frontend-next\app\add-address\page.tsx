import Component from '@/app/components/AddNewAddress';

export default function Page() {
  return <Component />;
}
