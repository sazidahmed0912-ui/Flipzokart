import { ForgotPasswordPage as Component } from '@/app/_pages/ForgotPassword';

export default function Page() {
  return <Component />;
}
