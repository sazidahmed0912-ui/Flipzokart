import { TrackOrderPage as Component } from '@/app/_pages/TrackOrderPage';

export default function Page() {
  return <Component />;
}
