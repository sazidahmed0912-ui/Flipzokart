import { LoginPage } from '@/app/_pages/LoginPage';

export default function AdminLoginPage() {
    return <LoginPage isAdmin={true} />;
}
