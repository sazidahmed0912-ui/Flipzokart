import { BannedPage as Component } from '@/app/_pages/BannedPage';

export default function Page() {
  return <Component />;
}
