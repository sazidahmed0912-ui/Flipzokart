import { PrivacyPolicyPage as Component } from '@/app/_pages/PrivacyPolicyPage';

export default function Page() {
  return <Component />;
}
