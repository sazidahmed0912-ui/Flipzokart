import Component from '@/app/_pages/CheckoutPage/CheckoutPage';

export default function Page() {
  return <Component />;
}
