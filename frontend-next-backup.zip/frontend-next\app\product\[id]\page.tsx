import { ProductDetails as Component } from '@/app/_pages/ProductDetails';

export default function Page() {
  return <Component />;
}
