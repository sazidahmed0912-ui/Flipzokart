import { TermsOfServicePage as Component } from '@/app/_pages/TermsOfServicePage';

export default function Page() {
  return <Component />;
}
