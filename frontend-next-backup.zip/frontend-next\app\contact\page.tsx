import { ContactUsPage as Component } from '@/app/_pages/ContactUsPage';

export default function Page() {
  return <Component />;
}
