import { InvoicePage as Component } from '@/app/_pages/InvoicePage';

export default function Page() {
  return <Component />;
}
