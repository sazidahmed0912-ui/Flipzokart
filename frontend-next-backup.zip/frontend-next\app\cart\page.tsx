import Component from '@/app/_pages/CartPage/CartPage';

export default function Page() {
  return <Component />;
}
