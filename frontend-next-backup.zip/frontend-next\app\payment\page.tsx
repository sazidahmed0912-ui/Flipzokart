import Component from '@/app/_pages/PaymentPage/PaymentPage';

export default function Page() {
  return <Component />;
}
