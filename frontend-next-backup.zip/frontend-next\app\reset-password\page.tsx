import { ResetPasswordPage as Component } from '@/app/_pages/ResetPasswordPage';

export default function Page() {
  return <Component />;
}
