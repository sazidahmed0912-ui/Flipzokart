
import { HomePage } from '@/app/_pages/HomePage';

export default function Page() {
  return <HomePage />;
}
