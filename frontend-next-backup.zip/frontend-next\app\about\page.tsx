import { AboutUsPage as Component } from '@/app/_pages/AboutUsPage';

export default function Page() {
  return <Component />;
}
