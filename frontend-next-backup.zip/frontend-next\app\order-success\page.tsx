import Component from '@/app/_pages/OrderSuccessPage';

export default function Page() {
  return <Component />;
}
