import { ShopPage as Component } from '@/app/_pages/ShopPage';

export default function Page() {
  return <Component />;
}
